package com.pocketmatrix.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

private val Bg = Color(0xFF090B10)
private val Panel = Color(0xFF141923)
private val Yellow = Color(0xFFFFD21F)
private val Green = Color(0xFF20C997)
private val Red = Color(0xFFFF5C6C)
private val Muted = Color(0xFF8993A4)

data class Candle(val open: Float, val high: Float, val low: Float, val close: Float)
enum class Signal { CALL, PUT, WAIT }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PocketMatrixApp() }
    }
}

@Composable
fun PocketMatrixApp() {
    var asset by remember { mutableStateOf("EUR/USD OTC") }
    var assetSearch by remember { mutableStateOf("") }
    var timeframe by remember { mutableStateOf("1M") }
    val candles = remember(asset, timeframe) { sampleCandles(56) }
    val signal = remember(candles) { SignalEngine.evaluate(candles) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Yellow,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Row(
                        Modifier.fillMaxWidth().padding(top = 20.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("POCKET", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                            Text("MATRIX", color = Yellow, fontSize = 22.sp, fontWeight = FontWeight.Black)
                        }
                        Surface(color = Panel, shape = RoundedCornerShape(50)) {
                            Text("SIGNAL LAB  •  v0.1", Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = Muted, fontSize = 10.sp)
                        }
                    }
                }
                item {
                    Column(
                        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("MERCADOS OTC", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("CATÁLOGO DE REFERENCIA", color = Muted, fontSize = 9.sp)
                        }
                        OutlinedTextField(
                            value = assetSearch,
                            onValueChange = { assetSearch = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            placeholder = { Text("Buscar activo OTC…", color = Muted) },
                            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp)
                        )
                        val otcAssets = listOf(
                            "CAD/JPY OTC", "CHF/JPY OTC", "CHF/NOK OTC", "EUR/HUF OTC",
                            "EUR/RUB OTC", "EUR/TRY OTC", "EUR/USD OTC", "GBP/AUD OTC",
                            "GBP/USD OTC", "NGN/USD OTC", "NZD/USD OTC"
                        )
                        val filteredAssets = otcAssets.filter { it.contains(assetSearch.trim(), ignoreCase = true) }
                        filteredAssets.forEach { symbol ->
                            Row(
                                Modifier.fillMaxWidth()
                                    .clickable { asset = symbol }
                                    .background(if (asset == symbol) Color(0xFF263246) else Color.Transparent, RoundedCornerShape(10.dp))
                                    .padding(horizontal = 8.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(symbol, color = if (asset == symbol) Yellow else Color.White, fontSize = 13.sp)
                                Text("Pago variable", color = Muted, fontSize = 11.sp)
                            }
                        }
                        Text("Activos tomados de la captura compartida. Lista parcial; disponibilidad y pago deben validarse en Pocket Option.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                    }
                }
                item {
                    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(asset, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                Text("OTC · cotización de demostración no oficial", color = Muted, fontSize = 11.sp)
                            }
                            Text("1.08426", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(12.dp))
                        CandleChart(candles, Modifier.fillMaxWidth().height(220.dp))
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("30S", "1M", "5M", "15M").forEach {
                                FilterChip(selected = timeframe == it, onClick = { timeframe = it }, label = { Text(it) })
                            }
                        }
                    }
                }
                item {
                    SignalCard(signal)
                }
                item {
                    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)) {
                        Text("ANÁLISIS TÉCNICO", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(Modifier.height(12.dp))
                        MetricRow("RSI (14)", "%.1f".format(rsi(candles)), "Zona de observación")
                        MetricRow("EMA (9)", "%.5f".format(ema(candles.map { it.close }, 9)), "Tendencia corta")
                        MetricRow("EMA (21)", "%.5f".format(ema(candles.map { it.close }, 21)), "Tendencia base")
                    }
                }
                item {
                    Text(
                        "MODO DEMO OTC · Los activos se basan parcialmente en tu captura. Los precios son sintéticos, no cotizaciones oficiales de Pocket Option. El pago cambia y debe verificarse en la plataforma. Las señales son experimentales.",
                        color = Muted, fontSize = 11.sp, lineHeight = 16.sp,
                        modifier = Modifier.padding(bottom = 24.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SignalCard(signal: Signal) {
    val accent = when (signal) { Signal.CALL -> Green; Signal.PUT -> Red; Signal.WAIT -> Yellow }
    val label = when (signal) { Signal.CALL -> "CALL"; Signal.PUT -> "PUT"; Signal.WAIT -> "ESPERAR" }
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)) {
        Text("SEÑAL AUTOMÁTICA", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text(label, color = accent, fontSize = 28.sp, fontWeight = FontWeight.Black)
            Surface(color = accent.copy(alpha = .14f), shape = RoundedCornerShape(50)) {
                Text(if (signal == Signal.WAIT) "SIN ENTRADA" else "SEÑAL EXPERIMENTAL", color = accent, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp), fontSize = 10.sp)
            }
        }
        Text("Regla inicial: cruce EMA 9/21 + filtro RSI. No usar con dinero real.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun MetricRow(name: String, value: String, note: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column {
            Text(name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(note, color = Muted, fontSize = 10.sp)
        }
        Text(value, color = Yellow, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
private fun CandleChart(data: List<Candle>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        if (data.isEmpty()) return@Canvas
        val minP = data.minOf { it.low }
        val maxP = data.maxOf { it.high }
        val span = max(maxP - minP, 0.0001f)
        val step = size.width / data.size
        val bodyW = step * .56f
        data.forEachIndexed { i, c ->
            val x = i * step + step / 2
            fun y(v: Float) = size.height - ((v - minP) / span) * (size.height - 12f) - 6f
            val color = if (c.close >= c.open) Green else Red
            drawLine(color, Offset(x, y(c.high)), Offset(x, y(c.low)), strokeWidth = 2f)
            val top = min(y(c.open), y(c.close))
            val bottom = max(y(c.open), y(c.close))
            drawRect(color, topLeft = Offset(x - bodyW / 2, top), size = androidx.compose.ui.geometry.Size(bodyW, max(3f, bottom - top)))
        }
        // Horizontal reference grid
        for (i in 1..3) {
            val gy = size.height * i / 4
            drawLine(Color(0xFF28303D), Offset(0f, gy), Offset(size.width, gy), strokeWidth = 1f)
        }
    }
}

private fun sampleCandles(count: Int): List<Candle> {
    val random = Random(42)
    var last = 1.084f
    return List(count) {
        val open = last
        val close = open + (random.nextFloat() - .49f) * .0012f
        val high = max(open, close) + random.nextFloat() * .00035f
        val low = min(open, close) - random.nextFloat() * .00035f
        last = close
        Candle(open, high, low, close)
    }
}

private fun ema(values: List<Float>, period: Int): Float {
    if (values.isEmpty()) return 0f
    val k = 2f / (period + 1f)
    return values.drop(1).fold(values.first()) { acc, v -> v * k + acc * (1 - k) }
}

private fun rsi(candles: List<Candle>, period: Int = 14): Float {
    val changes = candles.zipWithNext { a, b -> b.close - a.close }.takeLast(period)
    if (changes.isEmpty()) return 50f
    val gains = changes.filter { it > 0 }.sum()
    val losses = -changes.filter { it < 0 }.sum()
    if (losses == 0f) return 100f
    val rs = (gains / changes.size) / (losses / changes.size)
    return 100f - (100f / (1f + rs))
}

private object SignalEngine {
    fun evaluate(candles: List<Candle>): Signal {
        if (candles.size < 22) return Signal.WAIT
        val closes = candles.map { it.close }
        val fast = ema(closes, 9)
        val slow = ema(closes, 21)
        val momentum = rsi(candles)
        return when {
            fast > slow && momentum in 50f..68f -> Signal.CALL
            fast < slow && momentum in 32f..50f -> Signal.PUT
            else -> Signal.WAIT
        }
    }
}
