# Pocket Matrix — Android starter (v0.1)

This is a native Android/Jetpack Compose starter for a **signal-only prototype**.

## Included
- Dark black/yellow visual identity
- Searchable OTC selector seeded with symbols visible in the user's screenshot (partial catalog; availability/payout not live)
- Timeframe selectors
- Candlestick chart rendered with Compose Canvas
- Basic EMA(9), EMA(21), RSI(14) calculations
- Experimental CALL / PUT / WAIT rule
- Clear demo-data disclaimer

## Important limitations
- The chart currently uses deterministic synthetic candles. OTC symbols in the selector are seeded from the user's screenshot and are a **partial reference list, not a live platform catalog**. Prices and payouts are not live OTC market data and are **not Pocket Option's quote feed**.
- No Pocket Option login, session token, private endpoint, or trade execution is implemented.
- Signals are a software prototype, not financial advice or evidence of a profitable strategy.
- Pocket Option's public offer states that it uses its own quote sources and reserves the right to cancel/revise operations performed with unauthorized bot software. Review the current agreement before considering any integration.

## Build
1. Install Android Studio (current stable) and Android SDK 35.
2. Open this folder as an existing Gradle project.
3. Allow Gradle sync.
4. Run on an Android emulator or device (Android 8.0 / API 26 or later).
5. To create a debug APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Next development milestones
1. Confirm an authorized source for Pocket Option OTC prices; ordinary Forex feeds cannot be relabelled as OTC.
2. Replace `sampleCandles()` with timestamped OTC candles from a documented, licensed and compatible source.
3. Add a WebSocket/repository layer and timestamped OHLC aggregation.
4. Add backtesting and forward-testing with signal outcome tracking.
5. Add configurable strategy parameters and risk controls.
6. Evaluate any future Pocket Option integration only through a method explicitly authorized by the platform.

## Stack
- Kotlin
- Jetpack Compose
- Material 3
- Gradle Kotlin DSL


## Build an APK using only an Android phone (GitHub Actions)
1. Extract this project ZIP on the phone.
2. Create a GitHub repository in the browser.
3. Upload the **contents of this project folder** to the repository root, including `.github/workflows/android-apk.yml`.
4. Open the repository's **Actions** tab and select **Build Pocket Matrix APK**.
5. Tap **Run workflow** (or wait for the first push build to finish).
6. Open the completed run, scroll to **Artifacts**, and download `PocketMatrix-debug-apk`.
7. Extract the downloaded artifact and install `app-debug.apk`. Android may ask you to allow installation from that browser/file manager.

This produces a debug/test APK, not a Play Store release. The app still uses synthetic demo candles and is not connected to Pocket Option or live OTC prices.
